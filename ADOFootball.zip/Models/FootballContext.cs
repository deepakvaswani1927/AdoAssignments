﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace FootbalLeague2.Models
{
        public class FootballContext : DbContext
        {
            public FootballContext() : base("name=mydatabaseEntities")
            {
            }
            public DbSet<Football> Footballs { get; set; }
        }   
}